using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MovingIconScript : MonoBehaviour
{
    int i;
    public GameObject imageInScene;
    public Sprite[] imageIcon;
    // Start is called before the first frame update
    void Start()
    {

        StartCoroutine(MyCoroutineMethod());
    }

    public void couroutineHandler()
    {
        Debug.Log("............................................");
        StartCoroutine(MyCoroutineMethod());
    }
    IEnumerator MyCoroutineMethod()
    {
        for (i = 0; i < 28; i++)
        {
            imageInScene.GetComponent<Image>().sprite = imageIcon[i];
            yield return new WaitForSeconds(0.05f);
            /*    if (i == 9)
                {
                    for (int i = 8; i < 9; i--)
                    {
                        imageInScene.GetComponent<Image>().sprite = imageIcon[i];
                        yield return new WaitForSeconds(1f);
                    }
                }*/
        }

        yield return MyCoroutineMethod();

    }
    public void startCoroutineHandler(){
        StartCoroutine(startCorouinteHandler());
    }
    IEnumerator startCorouinteHandler()
    {

        yield return new WaitForSeconds(5f);
        StartCoroutine(MyCoroutineMethod());



    }
    // Update is called once per frame
    void Update()
    {

    }
}
